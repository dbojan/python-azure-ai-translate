#2024-06-17-1
#add "Translator" service in azure dashboard

#https://learn.microsoft.com/en-us/azure/ai-services/translator/quickstart-text-sdk?pivots=programming-language-python
#pip install azure-ai-translation-text==1.0.0b1

#https://learn.microsoft.com/en-us/azure/ai-services/translator/service-limits
#note: max 50000 characters per request, 2 000 000 characters monthly,
#roughly 33,300 characters per minute

#Each translation counts as a separate translation
#https://learn.microsoft.com/en-us/azure/ai-services/translator/translator-faq

#use something like this to split big file into smaller, each file 200 lines. probably could be made in python, too ...:
#"coreutils\bin\split.exe" -l 200 -d "input_file.txt" "input_file - split."  

#put file(s) to translate in the 'translate' folder. each must be less than 33000 characters.


# set `<your-key>`, `<your-endpoint>`, and  `<region>` variables with the values from the Azure portal
key = "ENTER"
endpoint = "ENTER"
region = "ENTER"


source_language = 'ru'
#sr-Latn'
#target_languages = ['bs', 'hr','sr-Cyrl', 'en']
target_languages = ['en']
#target_languages = ['bs']

#if your each file has more than 33000 characters in it, set pause_time to 60
pause_time = 0

import os, time

from azure.ai.translation.text import TextTranslationClient, TranslatorCredential
from azure.ai.translation.text.models import InputTextItem
from azure.core.exceptions import HttpResponseError

#Text Translation, not Document translation
credential = TranslatorCredential(key, region)
text_translator = TextTranslationClient(endpoint=endpoint, credential=credential)


indir = 'translate'



if not os.path.isdir(indir):
	print('Please pass *existing* directory name')
	exit()

dirWithFiles = os.listdir(indir)
dirWithFiles.sort

print (dirWithFiles)
counter = 1
for singleFile in dirWithFiles:
	singleFileWithPath = os.path.join(indir, singleFile)


	with open(singleFileWithPath, "r", encoding="utf-8") as fileInsideWithLoop:
		stInpuitText = fileInsideWithLoop.read()
		#print(stInpuitText)

		#stInpuitText = 'Но давайте задумаемся'



		try:

			if counter >1:
				time.sleep(pause_time)
			
			print(singleFile) #always inside folder, so no need for ..withPath

			input_text_elements = [ InputTextItem(text = stInpuitText) ]

			response = text_translator.translate(content = input_text_elements, to = target_languages, from_parameter = source_language)
			translation = response[0] if response else None

			if translation:
				for translated_text in translation.translations:
					with open(singleFile + '-' + translated_text.to + '-translated.txt', "w", encoding="utf-8") as fileOutputInsideWithLoop:
						fileOutputInsideWithLoop.write(translated_text.text)

					#print(f"Text was translated to: '{translated_text.to}' and the result is: '{translated_text.text}'.")
			

			counter = counter + 1

		except HttpResponseError as exception:
			print(f"Error Code: {exception.error.code}")
			print(f"Message: {exception.error.message}")










