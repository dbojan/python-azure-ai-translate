#2024-06-07-1
#add "Translator" service in azure dashboard

#https://learn.microsoft.com/en-us/azure/ai-services/translator/quickstart-text-sdk?pivots=programming-language-python
#pip install azure-ai-translation-text==1.0.0b1


from azure.ai.translation.text import TextTranslationClient, TranslatorCredential
from azure.ai.translation.text.models import InputTextItem
from azure.core.exceptions import HttpResponseError

# set `<your-key>`, `<your-endpoint>`, and  `<region>` variables with the values from the Azure portal
key = "ENTER"
#Text Translation not, document translation
endpoint = "ENTER"
region = "ENTER"

credential = TranslatorCredential(key, region)
text_translator = TextTranslationClient(endpoint=endpoint, credential=credential)


filename = '1.txt'
with open(filename, 'r', encoding="utf-8") as file:
	stInpuitText = file.read()
	
#stInpuitText = 'Но давайте задумаемся'



#Each translation counts as a separate translation
#https://learn.microsoft.com/en-us/azure/ai-services/translator/translator-faq

try:
	source_language = 'ru'
	#sr-Latn'
	#target_languages = ['bs', 'hr','sr-Cyrl', 'en']
	target_languages = ['sr-Cyrl','hr']


	input_text_elements = [ InputTextItem(text = stInpuitText) ]

	response = text_translator.translate(content = input_text_elements, to = target_languages, from_parameter = source_language)
	translation = response[0] if response else None

	if translation:
		for translated_text in translation.translations:
			with open(filename + '-' + translated_text.to + '.txt', "w", encoding="utf-8") as fb:
				fb.write(translated_text.text)
			#print(f"Text was translated to: '{translated_text.to}' and the result is: '{translated_text.text}'.")
		

except HttpResponseError as exception:
	print(f"Error Code: {exception.error.code}")
	print(f"Message: {exception.error.message}")

